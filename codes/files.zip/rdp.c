#include <stdio.h>
#include <ctype.h>

char input[100];
int i = 0;

void E(); void EP(); void T(); void TP(); void F();

void match(char ch) {
    if (input[i] == ch) i++;
    else { printf("String Rejected\n"); i = -1; }
}

/* E -> T E' */
void E() { T(); EP(); }

/* E' -> + T E' | epsilon */
void EP() {
    if (input[i] == '+') { match('+'); T(); EP(); }
}

/* T -> F T' */
void T() { F(); TP(); }

/* T' -> * F T' | epsilon */
void TP() {
    if (input[i] == '*') { match('*'); F(); TP(); }
}

/* F -> (E) | id */
void F() {
    if (isalnum(input[i])) { i++; }
    else if (input[i] == '(') {
        match('('); E();
        if (input[i] == ')') match(')');
        else { printf("String Rejected\n"); i = -1; }
    }
    else { printf("String Rejected\n"); i = -1; }
}

int main() {
    printf("Enter expression: ");
    scanf("%s", input);
    E();
    if (i != -1 && input[i] == '\0')
        printf("String Accepted\n");
    else
        printf("String Rejected\n");
    return 0;
}
