#include <stdio.h>

char input[100];
int i = 0;

/* S -> aSb | epsilon */
void S() {
    if (input[i] == 'a') {
        i++;    /* match 'a' */
        S();
        if (input[i] == 'b')
            i++;    /* match 'b' */
        else {
            printf("String Rejected\n");
            i = -1;
        }
    }
    /* epsilon production: do nothing */
}

int main() {
    printf("Enter string: ");
    scanf("%s", input);
    S();
    if (i != -1 && input[i] == '\0')
        printf("String Accepted\n");
    else
        printf("String Rejected\n");
    return 0;
}
